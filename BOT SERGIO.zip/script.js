document.addEventListener('DOMContentLoaded', () => {
    const montoInput = document.getElementById('monto');
    const diasInput = document.getElementById('dias');
    const calcularBtn = document.getElementById('calcularBtn');
    const resultadosPfBody = document.getElementById('resultadosPf').getElementsByTagName('tbody')[0];
    const resultadosFciBody = document.getElementById('resultadosFci').getElementsByTagName('tbody')[0];
    const lastUpdatedP = document.getElementById('last-updated');
    const ctx = document.getElementById('rendimientoChart').getContext('2d');
    let rendimientoChart;

    let tasasBancosData = null;
    let fciData = null;

    async function cargarDatos() {
        try {
            const responseTasas = await fetch('tasas_bancos.json?v=' + new Date().getTime()); // Cache buster
            if (!responseTasas.ok) throw new Error(`Error cargando tasas_bancos.json: ${responseTasas.statusText}`);
            tasasBancosData = await responseTasas.json();
            
            const responseFci = await fetch('fci_data.json?v=' + new Date().getTime()); // Cache buster
            if (!responseFci.ok) throw new Error(`Error cargando fci_data.json: ${responseFci.statusText}`);
            fciData = await responseFci.json();

            if (tasasBancosData.ultima_actualizacion) {
                const fechaActualizacion = new Date(tasasBancosData.ultima_actualizacion);
                lastUpdatedP.textContent = `Tasas de Plazos Fijos actualizadas el: ${fechaActualizacion.toLocaleString('es-AR')}`;
            } else {
                lastUpdatedP.textContent = "No se pudo determinar la fecha de actualización de tasas.";
            }
            
            // Calcular y mostrar por defecto al cargar la página si los datos están disponibles
            if (tasasBancosData && fciData) {
                calcularYMostrarResultados();
            }

        } catch (error) {
            console.error("Error al cargar los datos iniciales:", error);
            lastUpdatedP.textContent = "Error al cargar datos. Intente recargar la página.";
            resultadosPfBody.innerHTML = `<tr><td colspan="4">Error al cargar datos de tasas.</td></tr>`;
            resultadosFciBody.innerHTML = `<tr><td colspan="5">Error al cargar datos de FCI.</td></tr>`;
        }
    }

    function calcularYMostrarResultados() {
        if (!tasasBancosData || !fciData) {
            alert("Los datos de tasas o FCI no están cargados. Espere o recargue la página.");
            return;
        }

        const monto = parseFloat(montoInput.value);
        const dias = parseInt(diasInput.value);

        if (isNaN(monto) || monto <= 0 || isNaN(dias) || dias <= 0) {
            alert("Por favor, ingrese un monto y días válidos.");
            return;
        }

        // Limpiar resultados anteriores
        resultadosPfBody.innerHTML = '';
        resultadosFciBody.innerHTML = '';

        const resultadosCompletos = [];

        // Calcular Plazos Fijos
        if (tasasBancosData.tasas && tasasBancosData.tasas.length > 0) {
            tasasBancosData.tasas.forEach(banco => {
                const tna = parseFloat(banco.tna);
                const interesGanado = monto * (tna / 100 / 365) * dias;
                const capitalMasInteres = monto + interesGanado;
                
                const row = resultadosPfBody.insertRow();
                row.insertCell().textContent = banco.banco;
                row.insertCell().textContent = tna.toFixed(2);
                row.insertCell().textContent = interesGanado.toFixed(2);
                row.insertCell().textContent = capitalMasInteres.toFixed(2);

                resultadosCompletos.push({
                    nombre: banco.banco,
                    valorFinal: capitalMasInteres,
                    tipo: 'PF'
                });
            });
        } else {
             resultadosPfBody.innerHTML = `<tr><td colspan="4">No hay datos de tasas de Plazos Fijos disponibles.</td></tr>`;
        }


        // Calcular FCI
        if (fciData && fciData.length > 0) {
            fciData.forEach(fci => {
                const rendimientoMensualPct = parseFloat(fci.rendimiento_mensual_estimado_pct);
                // Convertir rendimiento mensual a diario: (1 + Rmensual)^(1/30) - 1
                const rendimientoDiario = Math.pow(1 + (rendimientoMensualPct / 100), 1/30) - 1;
                // Interés compuesto: Capital * ((1 + Rdiario)^Días - 1)
                const interesGanado = monto * (Math.pow(1 + rendimientoDiario, dias) - 1);
                const capitalMasInteres = monto + interesGanado;

                const row = resultadosFciBody.insertRow();
                const logoCell = row.insertCell();
                if (fci.logo) {
                    const img = document.createElement('img');
                    img.src = fci.logo;
                    img.alt = fci.nombre;
                    img.style.maxWidth = '30px';
                    img.style.verticalAlign = 'middle';
                    logoCell.appendChild(img);
                } else {
                    logoCell.textContent = '-';
                }
                
                row.insertCell().textContent = fci.nombre;
                row.insertCell().textContent = rendimientoMensualPct.toFixed(2);
                row.insertCell().textContent = interesGanado.toFixed(2);
                row.insertCell().textContent = capitalMasInteres.toFixed(2);

                resultadosCompletos.push({
                    nombre: fci.nombre,
                    valorFinal: capitalMasInteres,
                    tipo: 'FCI'
                });
            });
        } else {
            resultadosFciBody.innerHTML = `<tr><td colspan="5">No hay datos de FCI disponibles.</td></tr>`;
        }
        

        // Actualizar gráfico
        actualizarGrafico(resultadosCompletos, monto);
    }

    function actualizarGrafico(resultados, montoBase) {
        if (rendimientoChart) {
            rendimientoChart.destroy();
        }

        // Ordenar por valor final descendente para mejor visualización
        resultados.sort((a, b) => b.valorFinal - a.valorFinal);

        const labels = resultados.map(r => r.nombre);
        const data = resultados.map(r => r.valorFinal);
        
        // Colores diferentes para PF y FCI
        const backgroundColors = resultados.map(r => r.tipo === 'PF' ? 'rgba(54, 162, 235, 0.7)' : 'rgba(75, 192, 192, 0.7)');
        const borderColors = resultados.map(r => r.tipo === 'PF' ? 'rgba(54, 162, 235, 1)' : 'rgba(75, 192, 192, 1)');

        rendimientoChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Capital + Interés (ARS)',
                    data: data,
                    backgroundColor: backgroundColors,
                    borderColor: borderColors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                scales: {
                    y: {
                        beginAtZero: false, // Empezar cerca del monto base para mejor visualización de diferencias
                        min: montoBase * 0.98, // Un poco por debajo del monto inicial para que se vea la base
                        title: {
                            display: true,
                            text: 'Monto Final (ARS)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Instrumento Financiero'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    label += new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' }).format(context.parsed.y);
                                }
                                const item = resultados[context.dataIndex];
                                if (item.tipo === 'PF') {
                                    const bancoData = tasasBancosData.tasas.find(b => b.banco === item.nombre);
                                    if(bancoData) label += ` (TNA: ${bancoData.tna.toFixed(2)}%)`;
                                } else if (item.tipo === 'FCI') {
                                    const fciItem = fciData.find(f => f.nombre === item.nombre);
                                    if(fciItem) label += ` (Rend. Mensual Est.: ${fciItem.rendimiento_mensual_estimado_pct.toFixed(2)}%)`;
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
    }

    calcularBtn.addEventListener('click', calcularYMostrarResultados);

    // Cargar datos al iniciar
    cargarDatos();
});